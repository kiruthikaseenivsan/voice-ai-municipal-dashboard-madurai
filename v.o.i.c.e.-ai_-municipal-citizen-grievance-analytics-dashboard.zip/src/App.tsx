import { useState, useEffect, useMemo } from "react";
import { 
  Volume2, 
  VolumeX,
  AlertTriangle, 
  CheckCircle2, 
  Plus, 
  Search, 
  Filter, 
  Trash2, 
  MapPin, 
  Sparkles, 
  Languages, 
  Activity, 
  ShieldCheck, 
  ArrowRight, 
  Database,
  ExternalLink,
  ChevronRight,
  Clock,
  Check,
  Smartphone,
  EyeOff,
  UserCheck,
  Server,
  Info
} from "lucide-react";

// Grievance Structure Definition
interface Grievance {
  id: string;
  zone: string;
  rawText: string;
  redactedText: string;
  category: string;
  translatedText: string;
  severity: number; // 1 to 5
  status: "SUCCESS_LOGGED" | "INGEST_PENDING";
  timestamp: string;
  hasPii: boolean;
  redactedPhone?: string;
  audioDuration?: string;
  confidenceScore: number; // Simulated AI classifier confidence
}

// Preset Citizen Complaints representing real Madurai dialectal speech transcriptions
const COMPLAINT_PRESETS = [
  {
    zone: "Mattuthavani",
    label: "Pothole Risk (Mattuthavani)",
    raw: "Mattuthavani entrance road-la severe pothole collapse. Accidents block risk very high +91 9444102938 direct risk",
    category: "Roads & Highways",
    translated: "Severe pothole collapse at the Mattuthavani entrance road. Risk of accidents and blockages is extremely high.",
    severity: 5,
    confidenceScore: 0.96,
  },
  {
    zone: "Periyar",
    label: "Garbage Dump (Periyar)",
    raw: "Periyar bus stand opposite full trash garbage accumulation area inside, foul smell coming since 3 days and water clogging.",
    category: "Sanitation & Waste",
    translated: "Complete trash and garbage accumulation opposite Periyar Bus Stand. Offensive odor emanating for the last 3 days with water clogging.",
    severity: 4,
    confidenceScore: 0.91,
  },
  {
    zone: "Goripalayam",
    label: "Dark Junction (Goripalayam)",
    raw: "Goripalayam signal street light block out. Full dark road night visibility zero risk danger",
    category: "Electrical & Streetlights",
    translated: "Complete street light failure at the Goripalayam signal junction. The street is pitch dark, resulting in zero night visibility and dangerous conditions.",
    severity: 4,
    confidenceScore: 0.89,
  },
  {
    zone: "Arappalayam",
    label: "Water Leak (Arappalayam)",
    raw: "Arappalayam cross road street water pipeline broken leak, clean drinking water waste fully flowing down the drainage channel.",
    category: "Water Supply",
    translated: "Broken water pipeline leaking clean drinking water on Arappalayam cross road, causing large amounts of water to flow into the drainage channel.",
    severity: 3,
    confidenceScore: 0.94,
  },
  {
    zone: "Anna Nagar",
    label: "Stray Dog Menace (Anna Nagar)",
    raw: "Anna Nagar main street dog menace near park kids cannot play safely and bite fear 0452-2534567",
    category: "Public Safety",
    translated: "Stray dog menace on Anna Nagar Main Street near the park. Children are unable to play safely due to fear of bites.",
    severity: 4,
    confidenceScore: 0.92,
  }
];

export default function App() {
  // Pre-seeded Grievance Database Matrix
  const [grievances, setGrievances] = useState<Grievance[]>([
    {
      id: "MDU-VOICE-84920",
      zone: "Mattuthavani",
      rawText: "Mattuthavani entrance road-la severe pothole collapse. Accidents block risk very high +91 9444102938 direct risk",
      redactedText: "Mattuthavani entrance road-la severe pothole collapse. Accidents block risk very high [REDACTED_PHONE_NUMBER_CONFIDENTIAL] direct risk",
      category: "Roads & Highways",
      translatedText: "Severe pothole collapse at the Mattuthavani entrance road. Risk of accidents and blockages is extremely high.",
      severity: 5,
      status: "SUCCESS_LOGGED",
      timestamp: "2026-07-04 02:45 AM",
      hasPii: true,
      redactedPhone: "+91 9444102938",
      audioDuration: "0:14",
      confidenceScore: 0.96
    },
    {
      id: "MDU-VOICE-83110",
      zone: "Periyar",
      rawText: "Periyar bus stand opposite full trash garbage accumulation area inside, foul smell coming since 3 days and water clogging.",
      redactedText: "Periyar bus stand opposite full trash garbage accumulation area inside, foul smell coming since 3 days and water clogging.",
      category: "Sanitation & Waste",
      translatedText: "Complete trash and garbage accumulation opposite Periyar Bus Stand. Offensive odor emanating for the last 3 days with water clogging.",
      severity: 4,
      status: "SUCCESS_LOGGED",
      timestamp: "2026-07-04 02:15 AM",
      hasPii: false,
      audioDuration: "0:22",
      confidenceScore: 0.91
    },
    {
      id: "MDU-VOICE-79402",
      zone: "Goripalayam",
      rawText: "Goripalayam signal street light block out. Full dark road night visibility zero risk danger",
      redactedText: "Goripalayam signal street light block out. Full dark road night visibility zero risk danger",
      category: "Electrical & Streetlights",
      translatedText: "Complete street light failure at the Goripalayam signal junction. The street is pitch dark, resulting in zero night visibility and dangerous conditions.",
      severity: 4,
      status: "SUCCESS_LOGGED",
      timestamp: "2026-07-03 11:30 PM",
      hasPii: false,
      audioDuration: "0:08",
      confidenceScore: 0.89
    },
    {
      id: "MDU-VOICE-78211",
      zone: "Arappalayam",
      rawText: "Arappalayam cross road street water pipeline broken leak, clean drinking water waste fully flowing down the drainage channel.",
      redactedText: "Arappalayam cross road street water pipeline broken leak, clean drinking water waste fully flowing down the drainage channel.",
      category: "Water Supply",
      translatedText: "Broken water pipeline leaking clean drinking water on Arappalayam cross road, causing large amounts of water to flow into the drainage channel.",
      severity: 3,
      status: "SUCCESS_LOGGED",
      timestamp: "2026-07-03 08:10 PM",
      hasPii: false,
      audioDuration: "0:19",
      confidenceScore: 0.94
    },
    {
      id: "MDU-VOICE-71050",
      zone: "Anna Nagar",
      rawText: "Anna Nagar main street dog menace near park kids cannot play safely and bite fear 0452-2534567",
      redactedText: "Anna Nagar main street dog menace near park kids cannot play safely and bite fear [REDACTED_PHONE_NUMBER_CONFIDENTIAL]",
      category: "Public Safety",
      translatedText: "Stray dog menace on Anna Nagar Main Street near the park. Children are unable to play safely due to fear of bites.",
      severity: 4,
      status: "SUCCESS_LOGGED",
      timestamp: "2026-07-03 04:40 PM",
      hasPii: true,
      redactedPhone: "0452-2534567",
      audioDuration: "0:12",
      confidenceScore: 0.92
    }
  ]);

  // Form State Variables
  const [selectedZone, setSelectedZone] = useState<string>("Mattuthavani");
  const [rawInput, setRawInput] = useState<string>("");
  const [autoSanitize, setAutoSanitize] = useState<boolean>(true);
  const [autoTranslate, setAutoTranslate] = useState<boolean>(true);

  // Filter & Search States
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [zoneFilter, setZoneFilter] = useState<string>("ALL");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [severityFilter, setSeverityFilter] = useState<string>("ALL");

  // Interaction States
  const [selectedGrievance, setSelectedGrievance] = useState<Grievance | null>(null);
  const [isAudioStreaming, setIsAudioStreaming] = useState<boolean>(true);
  const [waveFrequency, setWaveFrequency] = useState<number>(30); // sound wave bar count
  const [systemTime, setSystemTime] = useState<string>("2026-07-04 03:05 AM");

  // Ingestion Processing Simulation States
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [processingStep, setProcessingStep] = useState<string>("");
  const [processingProgress, setProcessingProgress] = useState<number>(0);

  // Soundwave heights list
  const [soundwaveHeights, setSoundwaveHeights] = useState<number[]>([]);

  // Update digital system clock simulating real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date();
      setSystemTime(
        now.toLocaleString("en-US", {
          year: "numeric",
          month: "2-digit",
          day: "2-digit",
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        })
      );
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Update dynamic voice wave height patterns periodically
  useEffect(() => {
    const interval = setInterval(() => {
      if (isAudioStreaming) {
        const heights = Array.from({ length: 24 }, () => Math.floor(Math.random() * 80) + 20);
        setSoundwaveHeights(heights);
      } else {
        setSoundwaveHeights(Array(24).fill(15));
      }
    }, 180);
    return () => clearInterval(interval);
  }, [isAudioStreaming]);

  // Handle Preset Autofill Sequence
  const applyPreset = (preset: typeof COMPLAINT_PRESETS[0]) => {
    setSelectedZone(preset.zone);
    setRawInput(preset.raw);
  };

  // Perform Simulated Dravidian/Tamil English parsing pipeline sequence
  const executeIngestPipeline = () => {
    if (!rawInput.trim()) return;

    setIsProcessing(true);
    setProcessingProgress(10);
    setProcessingStep("Initializing secure V.O.I.C.E. extraction node...");

    // Timing simulation for interactive cognitive pipeline layers
    setTimeout(() => {
      setProcessingProgress(35);
      setProcessingStep("Executing PII Masking regex logic: telephone & digit sanitization...");
    }, 300);

    setTimeout(() => {
      setProcessingProgress(60);
      setProcessingStep("Translating linguistic prose: dialectal semantic cross-mapping...");
    }, 700);

    setTimeout(() => {
      setProcessingProgress(85);
      setProcessingStep("Assessing priority weight and category classification...");
    }, 1100);

    setTimeout(() => {
      setProcessingProgress(100);
      setProcessingStep("Publishing verified schema row into target BigQuery database...");

      // Core cognitive simulation logic
      const phoneRegex = /(\+?\d{1,4}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}|\b\d{10}\b|\b\d{4}-\d{7}\b/g;
      const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
      
      let hasPii = false;
      let redactedText = rawInput;
      let detectedPhone = "";

      const phoneMatches = rawInput.match(phoneRegex);
      if (phoneMatches && phoneMatches.length > 0) {
        hasPii = true;
        detectedPhone = phoneMatches[0];
        if (autoSanitize) {
          redactedText = redactedText.replace(phoneRegex, "[REDACTED_PHONE_NUMBER_CONFIDENTIAL]");
        }
      }

      const emailMatches = rawInput.match(emailRegex);
      if (emailMatches && emailMatches.length > 0) {
        hasPii = true;
        if (autoSanitize) {
          redactedText = redactedText.replace(emailRegex, "[REDACTED_EMAIL_CONFIDENTIAL]");
        }
      }

      // Keyword Classification Rules
      let category = "General Inquiries";
      const textLower = rawInput.toLowerCase();
      
      if (textLower.includes("road") || textLower.includes("pothole") || textLower.includes("pavement") || textLower.includes("collapse")) {
        category = "Roads & Highways";
      } else if (textLower.includes("water") || textLower.includes("pipe") || textLower.includes("leak") || textLower.includes("flow") || textLower.includes("drainage")) {
        category = "Water Supply";
      } else if (textLower.includes("garbage") || textLower.includes("trash") || textLower.includes("dump") || textLower.includes("smell") || textLower.includes("foul")) {
        category = "Sanitation & Waste";
      } else if (textLower.includes("light") || textLower.includes("streetlight") || textLower.includes("dark") || textLower.includes("visibility")) {
        category = "Electrical & Streetlights";
      } else if (textLower.includes("dog") || textLower.includes("menace") || textLower.includes("bite") || textLower.includes("danger") || textLower.includes("hazard")) {
        category = "Public Safety";
      }

      // Severity Scoring 1-5
      let severity = 3;
      if (textLower.includes("accident") || textLower.includes("die") || textLower.includes("hazard") || textLower.includes("zero visibility") || textLower.includes("very high")) {
        severity = 5;
      } else if (textLower.includes("foul") || textLower.includes("smell") || textLower.includes("waste") || textLower.includes("menace") || textLower.includes("leak") || textLower.includes("dark")) {
        severity = 4;
      } else if (textLower.includes("clogging") || textLower.includes("dump") || textLower.includes("block")) {
        severity = 3;
      } else if (textLower.includes("repair") || textLower.includes("light")) {
        severity = 2;
      }

      // Translation Matching Strategy
      let translatedText = rawInput;
      const matchedPreset = COMPLAINT_PRESETS.find(p => 
        rawInput.toLowerCase().trim() === p.raw.toLowerCase().trim() || 
        rawInput.toLowerCase().includes(p.raw.substring(0, 15).toLowerCase())
      );

      if (matchedPreset && autoTranslate) {
        translatedText = matchedPreset.translated;
      } else if (autoTranslate) {
        // Dynamic smart English fallback translation synthesis
        const cleanedText = rawInput.replace(phoneRegex, "").replace(emailRegex, "").trim();
        translatedText = `Dialect Mapping Result for ${selectedZone}: ${cleanedText.charAt(0).toUpperCase() + cleanedText.slice(1)}. [Cognitive classification identifies high relevance toward municipal ${category.toLowerCase()}].`;
      }

      const generatedId = `MDU-VOICE-${Math.floor(10000 + Math.random() * 90000)}`;
      const timestampString = new Date().toLocaleString("en-US", {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
      });

      const newGrievance: Grievance = {
        id: generatedId,
        zone: selectedZone,
        rawText: rawInput,
        redactedText,
        category,
        translatedText,
        severity,
        status: "SUCCESS_LOGGED", // Flashing green status indicator
        timestamp: timestampString,
        hasPii,
        redactedPhone: detectedPhone || undefined,
        audioDuration: `0:${Math.floor(Math.random() * 20) + 10}`,
        confidenceScore: parseFloat((0.85 + Math.random() * 0.14).toFixed(2))
      };

      setGrievances((prev) => [newGrievance, ...prev]);
      setRawInput("");
      setIsProcessing(false);
      setProcessingStep("");
      setProcessingProgress(0);
      
      // Auto-select the newly added grievance to display dynamic inspection insights
      setSelectedGrievance(newGrievance);
    }, 1500);
  };

  // Delete Grievance
  const deleteGrievance = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setGrievances((prev) => prev.filter((g) => g.id !== id));
    if (selectedGrievance?.id === id) {
      setSelectedGrievance(null);
    }
  };

  // Computed Analytical KPIs
  const totalGrievances = grievances.length;
  
  const criticalActionRequired = useMemo(() => {
    return grievances.filter((g) => g.severity >= 4).length;
  }, [grievances]);

  const piiMaskedCount = useMemo(() => {
    return grievances.filter((g) => g.hasPii).length;
  }, [grievances]);

  const categoryBreakdown = useMemo(() => {
    const map: { [key: string]: number } = {
      "Roads & Highways": 0,
      "Sanitation & Waste": 0,
      "Electrical & Streetlights": 0,
      "Water Supply": 0,
      "Public Safety": 0,
    };
    grievances.forEach((g) => {
      if (map[g.category] !== undefined) {
        map[g.category]++;
      } else {
        map["General"] = (map["General"] || 0) + 1;
      }
    });
    return map;
  }, [grievances]);

  // Filtered dataset
  const filteredGrievances = useMemo(() => {
    return grievances.filter((g) => {
      const matchSearch = 
        g.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        g.zone.toLowerCase().includes(searchQuery.toLowerCase()) ||
        g.rawText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        g.translatedText.toLowerCase().includes(searchQuery.toLowerCase()) ||
        g.category.toLowerCase().includes(searchQuery.toLowerCase());

      const matchZone = zoneFilter === "ALL" || g.zone === zoneFilter;
      const matchCategory = categoryFilter === "ALL" || g.category === categoryFilter;
      const matchSeverity = severityFilter === "ALL" || g.severity.toString() === severityFilter;

      return matchSearch && matchZone && matchCategory && matchSeverity;
    });
  }, [grievances, searchQuery, zoneFilter, categoryFilter, severityFilter]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-teal-500 selection:text-slate-950 flex flex-col">
      
      {/* Upper Navigation / Status bar */}
      <header id="nav-header" className="border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-6 py-4">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-teal-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-teal-500/10">
              <Sparkles className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-extrabold text-lg tracking-wider text-teal-400">V.O.I.C.E. AI</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-slate-900 text-slate-400 font-mono border border-slate-800">v2.4-MADURAI</span>
              </div>
              <h1 className="text-xs text-slate-400 tracking-wide">Voice-Optimized Ingestion & Cognitive Extraction</h1>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono">
            <div className="px-3 py-1.5 rounded-md bg-slate-900/60 border border-slate-900 flex items-center gap-2 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-teal-500 animate-pulse" />
              <span>MADURAI SECURE ZONE: {systemTime}</span>
            </div>
            <div className="px-3 py-1.5 rounded-md bg-slate-900/60 border border-slate-900 flex items-center gap-2 text-emerald-400">
              <Server className="w-3.5 h-3.5 text-emerald-500" />
              <span>BIGQUERY PIPELINE: ACTIVE</span>
            </div>
          </div>

        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">

        {/* Hero Section with Beautiful Voice Wave Animation Style Banner */}
        <section id="voice-wave-hero" className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-slate-950 border border-slate-800 p-6 md:p-8">
          
          {/* Subtle background glowing mesh dots */}
          <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#0ea5e9_1px,transparent_1px)] [background-size:16px_16px] pointer-events-none"></div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            
            <div className="lg:col-span-7 space-y-3">
              <div className="inline-flex items-center gap-2 bg-teal-500/10 border border-teal-500/20 text-teal-400 px-3 py-1 rounded-full text-xs font-medium">
                <span className="w-2 h-2 rounded-full bg-teal-400 animate-ping"></span>
                Madurai Smart Citizen Service Nodes Stream
              </div>
              <h2 className="text-3xl md:text-4xl font-display font-bold tracking-tight text-white">
                Municipal Citizen Grievance Analytics
              </h2>
              <p className="text-slate-400 text-sm max-w-2xl leading-relaxed">
                Empowering the Madurai Corporation with cognitive real-time semantic processing. Raw spoken local dialects and unstructured complaints (Tamil & English mixed prose) are converted instantly into structured, prioritized records optimized for GIS dispatch and BigQuery pipeline analytics.
              </p>
            </div>

            {/* Voice Wave Animation Banner Column */}
            <div className="lg:col-span-5 bg-slate-950/60 rounded-xl p-5 border border-slate-800/80 flex flex-col justify-between h-44">
              <div className="flex items-center justify-between text-xs text-slate-400 font-mono">
                <div className="flex items-center gap-2">
                  <Activity className="w-3.5 h-3.5 text-teal-400" />
                  <span>AMBIENT CITIZEN AUDIO FEED FEEDBACK</span>
                </div>
                <button 
                  onClick={() => setIsAudioStreaming(!isAudioStreaming)}
                  className={`px-2 py-1 rounded border flex items-center gap-1.5 transition-all cursor-pointer ${
                    isAudioStreaming 
                      ? "border-teal-500/30 text-teal-400 hover:bg-teal-500/10" 
                      : "border-slate-800 text-slate-500 hover:bg-slate-900"
                  }`}
                >
                  {isAudioStreaming ? (
                    <>
                      <Volume2 className="w-3 h-3 animate-bounce" />
                      <span>STREAMING</span>
                    </>
                  ) : (
                    <>
                      <VolumeX className="w-3 h-3" />
                      <span>MUTED</span>
                    </>
                  )}
                </button>
              </div>

              {/* High-fidelity CSS soundwave vertical equalizer */}
              <div className="h-16 flex items-end justify-center gap-1.5 px-2 my-2">
                {soundwaveHeights.length > 0 ? (
                  soundwaveHeights.map((ht, idx) => (
                    <div
                      key={idx}
                      style={{ height: `${ht}%` }}
                      className={`w-1 md:w-1.5 rounded-full transition-all duration-150 ${
                        isAudioStreaming
                          ? idx % 3 === 0
                            ? "bg-teal-400/90"
                            : idx % 3 === 1
                            ? "bg-teal-500/80"
                            : "bg-indigo-500/80"
                          : "bg-slate-800"
                      }`}
                    ></div>
                  ))
                ) : (
                  Array.from({ length: 24 }).map((_, idx) => (
                    <div
                      key={idx}
                      className="w-1 md:w-1.5 h-[15%] rounded-full bg-slate-800"
                    ></div>
                  ))
                )}
              </div>

              <div className="grid grid-cols-5 text-[10px] font-mono text-center text-slate-500 border-t border-slate-900/80 pt-2">
                <span>MATTU-T</span>
                <span>PERIYAR</span>
                <span>GORI-P</span>
                <span>ARAPPA-Y</span>
                <span>ANNA-N</span>
              </div>

            </div>

          </div>
        </section>

        {/* Dashboard Panels Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">

          {/* Left Side: Submit Payload, Audio presets, Configuration controls */}
          <div className="lg:col-span-4 space-y-6">

            {/* Ingestion Panel Card */}
            <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-5 md:p-6 space-y-5">
              
              <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
                <Plus className="w-5 h-5 text-teal-400" />
                <h3 className="font-display font-semibold text-white">Active Grievance Simulator</h3>
              </div>

              {/* Node Presets Quick Link */}
              <div className="space-y-2">
                <span className="text-xs text-slate-400 font-mono block">CLICK ACTIVE NODES EXCERPT TO PRE-FILL:</span>
                <div className="flex flex-wrap gap-2">
                  {COMPLAINT_PRESETS.map((p, index) => (
                    <button
                      key={index}
                      onClick={() => applyPreset(p)}
                      className="text-xs px-2.5 py-1.5 rounded-md bg-slate-950/80 text-slate-300 border border-slate-800/80 hover:border-teal-500/40 hover:text-teal-400 transition-all text-left flex items-center gap-1.5 cursor-pointer"
                    >
                      <MapPin className="w-3 h-3 text-indigo-400 shrink-0" />
                      <span>{p.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Active form inputs */}
              <div className="space-y-4 pt-2">
                
                {/* Location Zone selection dropdown */}
                <div className="space-y-1.5">
                  <label htmlFor="location-zone" className="text-xs font-mono text-slate-300 flex items-center justify-between">
                    <span>1. CHOOSE TARGET ZONE</span>
                    <span className="text-[10px] text-teal-500">GIS BOUNDS ACTIVE</span>
                  </label>
                  <select
                    id="location-zone"
                    value={selectedZone}
                    onChange={(e) => setSelectedZone(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-slate-200 focus:outline-none focus:border-teal-500/80"
                  >
                    <option value="Mattuthavani">Mattuthavani Zone</option>
                    <option value="Periyar">Periyar Bus Stand Zone</option>
                    <option value="Goripalayam">Goripalayam Signal Zone</option>
                    <option value="Arappalayam">Arappalayam Cross Zone</option>
                    <option value="Anna Nagar">Anna Nagar Park Zone</option>
                  </select>
                </div>

                {/* Complaint unstructured text-area */}
                <div className="space-y-1.5">
                  <div className="flex justify-between items-center">
                    <label htmlFor="complaint-text" className="text-xs font-mono text-slate-300">
                      2. RAW CITIZEN DIALECT PAYLOAD
                    </label>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {rawInput.length} chars
                    </span>
                  </div>
                  <textarea
                    id="complaint-text"
                    rows={4}
                    value={rawInput}
                    onChange={(e) => setRawInput(e.target.value)}
                    placeholder="Type raw regional language prose (mixed English and Tamil) with telephone numbers or PII info to see auto-redaction and extraction logic in action..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-sm text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-teal-500/80 leading-relaxed font-sans"
                  />
                </div>

                {/* Cognitive switches */}
                <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 space-y-2.5">
                  <span className="text-[10px] font-mono text-slate-500 block tracking-wider uppercase">Pipeline Engine Config</span>
                  
                  <div className="flex items-center justify-between">
                    <label htmlFor="pii-sanitize" className="text-xs text-slate-300 flex items-center gap-2 cursor-pointer">
                      <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                      <span>Scrub PII & Telephone</span>
                    </label>
                    <input
                      id="pii-sanitize"
                      type="checkbox"
                      checked={autoSanitize}
                      onChange={(e) => setAutoSanitize(e.target.checked)}
                      className="accent-teal-500 h-4 w-4 rounded bg-slate-950 border-slate-800"
                    />
                  </div>

                  <div className="flex items-center justify-between">
                    <label htmlFor="auto-translate" className="text-xs text-slate-300 flex items-center gap-2 cursor-pointer">
                      <Languages className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Semantic Translation</span>
                    </label>
                    <input
                      id="auto-translate"
                      type="checkbox"
                      checked={autoTranslate}
                      onChange={(e) => setAutoTranslate(e.target.checked)}
                      className="accent-teal-500 h-4 w-4 rounded bg-slate-950 border-slate-800"
                    />
                  </div>
                </div>

                {/* Process Button */}
                <button
                  onClick={executeIngestPipeline}
                  disabled={isProcessing || !rawInput.trim()}
                  className={`w-full py-2.5 px-4 rounded-lg font-display font-bold text-sm tracking-wide transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer ${
                    !rawInput.trim() 
                      ? "bg-slate-800/40 text-slate-500 border border-slate-900 cursor-not-allowed"
                      : isProcessing
                      ? "bg-teal-500/20 text-teal-400 border border-teal-500/40"
                      : "bg-teal-500 text-slate-950 hover:bg-teal-400 hover:shadow-lg hover:shadow-teal-500/20"
                  }`}
                >
                  {isProcessing ? (
                    <>
                      <div className="w-4 h-4 rounded-full border-2 border-teal-400 border-t-transparent animate-spin"></div>
                      <span>INGESTING PAYLOAD...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 shrink-0" />
                      <span>INGEST & PROCESS PAYLOAD SEQUENCE</span>
                    </>
                  )}
                </button>

              </div>

            </div>

            {/* Ingestion trace panel (Always shows status of current stream processing) */}
            <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-5 font-mono space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-2">
                <div className="flex items-center gap-1.5 text-xs text-slate-300">
                  <Activity className="w-4 h-4 text-indigo-400 animate-pulse" />
                  <span>COGNITIVE TRANSLATION REPORT</span>
                </div>
                <span className="text-[10px] text-slate-500">NODE_3000_INGRESS</span>
              </div>

              {isProcessing ? (
                <div className="space-y-3 py-2">
                  <div className="w-full bg-slate-950 rounded-full h-1.5 overflow-hidden border border-slate-800">
                    <div 
                      style={{ width: `${processingProgress}%` }}
                      className="bg-teal-500 h-1.5 rounded-full transition-all duration-300"
                    ></div>
                  </div>
                  <p className="text-xs text-teal-400 animate-pulse">{processingStep}</p>
                </div>
              ) : selectedGrievance ? (
                <div className="space-y-3 text-xs leading-relaxed">
                  <div className="p-2.5 rounded bg-slate-950/80 border border-slate-900 space-y-1.5">
                    <span className="text-[9px] text-indigo-400 uppercase tracking-widest block">Original Regional Input</span>
                    <p className="text-slate-300 italic">"{selectedGrievance.rawText}"</p>
                  </div>

                  <div className="p-2.5 rounded bg-slate-950/80 border border-slate-900 space-y-1.5">
                    <span className="text-[9px] text-teal-400 uppercase tracking-widest block">PII scrubbing & telephone mask</span>
                    <p className="text-slate-300">
                      {selectedGrievance.hasPii ? (
                        <span className="text-amber-400/90 font-medium">🛡️ Redacted phone: "{selectedGrievance.redactedPhone}" safely filtered.</span>
                      ) : (
                        <span className="text-slate-400">No telephone or confidential PII markers detected.</span>
                      )}
                    </p>
                  </div>

                  <div className="p-2.5 rounded bg-slate-950/80 border border-slate-900 space-y-1.5">
                    <span className="text-[9px] text-cyan-400 uppercase tracking-widest block">semantic english mapping</span>
                    <p className="text-slate-300">"{selectedGrievance.translatedText}"</p>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div className="bg-slate-950/60 p-2 rounded border border-slate-900 flex justify-between">
                      <span className="text-slate-500">CATEGORY:</span>
                      <span className="text-teal-400 font-bold">{selectedGrievance.category}</span>
                    </div>
                    <div className="bg-slate-950/60 p-2 rounded border border-slate-900 flex justify-between">
                      <span className="text-slate-500">SEVERITY:</span>
                      <span className="text-amber-400 font-bold">{selectedGrievance.severity}/5</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-6 text-slate-600 text-xs">
                  <Info className="w-8 h-8 mx-auto text-slate-700 mb-2" />
                  <p>Awaiting ingestion stream... Submit a raw complaint or select an active node preset to analyze the semantic cognitive layers.</p>
                </div>
              )}
            </div>

          </div>

          {/* Right Side: Analytical Counter Cards & Core Ingestion Grid Table */}
          <div className="lg:col-span-8 space-y-6">

            {/* Dynamic Counter KPI Grid */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              
              {/* Card 1: Total Logged */}
              <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:scale-110 transition-transform">
                  <Database className="w-12 h-12 text-teal-400" />
                </div>
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">TOTAL INGESTED</span>
                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl font-display font-extrabold text-white">{totalGrievances}</span>
                  <span className="text-xs text-teal-400 font-mono font-semibold">100% INGEST</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Grievance ledger table rows</span>
              </div>

              {/* Card 2: Critical Cases */}
              <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:scale-110 transition-transform">
                  <AlertTriangle className="w-12 h-12 text-rose-500" />
                </div>
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">CRITICAL ACTIONS</span>
                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl font-display font-extrabold text-rose-500">{criticalActionRequired}</span>
                  <span className="text-xs text-rose-400 font-mono bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20 font-semibold">
                    {totalGrievances > 0 ? Math.round((criticalActionRequired / totalGrievances) * 100) : 0}% SEVERE
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Severity score metric 4 or 5</span>
              </div>

              {/* Card 3: PII Redacted Safeguard */}
              <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:scale-110 transition-transform">
                  <ShieldCheck className="w-12 h-12 text-teal-400" />
                </div>
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">PII SAFEGUARD</span>
                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl font-display font-extrabold text-teal-400">{piiMaskedCount}</span>
                  <span className="text-xs text-teal-400 font-mono bg-teal-500/10 px-1.5 py-0.5 rounded border border-teal-500/20 font-semibold">
                    AUTO SCRUBMED
                  </span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Confidential records masked</span>
              </div>

              {/* Card 4: BigQuery Ingestion Rate */}
              <div className="bg-slate-900/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between relative overflow-hidden group">
                <div className="absolute top-0 right-0 p-3 opacity-10 group-hover:scale-110 transition-transform">
                  <Server className="w-12 h-12 text-teal-500" />
                </div>
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-wider block">BQ SYNC RATE</span>
                <div className="flex items-baseline gap-2 my-2">
                  <span className="text-3xl font-display font-extrabold text-emerald-400">100%</span>
                  <span className="text-xs text-slate-400 font-mono">REAL-TIME</span>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Zero queue backlog lag</span>
              </div>

            </div>

            {/* Category Breakdown visual slider */}
            <div className="bg-slate-900/30 border border-slate-900 rounded-xl p-4 md:p-5 space-y-3">
              <span className="text-xs font-mono text-slate-300 block tracking-wider uppercase">Categorized Resolution Units Distribution</span>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-3 pt-1">
                {Object.keys(categoryBreakdown).map((cat) => {
                  const val = categoryBreakdown[cat];
                  const percentage = totalGrievances > 0 ? Math.round((val / totalGrievances) * 100) : 0;
                  return (
                    <div key={cat} className="bg-slate-950 p-3 rounded-lg border border-slate-900 flex flex-col justify-between">
                      <span className="text-[11px] text-slate-400 truncate block font-sans" title={cat}>{cat}</span>
                      <div className="flex items-baseline gap-2 mt-1">
                        <span className="text-lg font-bold text-teal-400 font-display">{val}</span>
                        <span className="text-[10px] text-slate-500 font-mono">{percentage}%</span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full mt-2 overflow-hidden">
                        <div 
                          style={{ width: `${percentage}%` }} 
                          className="bg-gradient-to-r from-teal-500 to-indigo-500 h-full rounded-full"
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Core Analytical Data Table Grid */}
            <div className="bg-slate-900/40 border border-slate-900 rounded-xl overflow-hidden">
              
              {/* Table header & interactive filter options */}
              <div className="p-4 md:p-5 border-b border-slate-900 space-y-4">
                
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-center gap-2">
                    <Database className="w-5 h-5 text-indigo-400 animate-pulse" />
                    <h3 className="font-display font-semibold text-white">Active Grievance Ledger Matrix</h3>
                  </div>
                  
                  {/* Ledger Record Counter */}
                  <span className="text-xs font-mono text-slate-400 bg-slate-950 border border-slate-800 px-2.5 py-1 rounded-full">
                    LEDGER COUNT: {filteredGrievances.length} OF {totalGrievances} ROWS
                  </span>
                </div>

                {/* Filters Row */}
                <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                  
                  {/* Search bar */}
                  <div className="relative sm:col-span-1.5">
                    <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search ledger items..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg pl-9 pr-3 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-teal-500/80"
                    />
                  </div>

                  {/* Filter by Zone */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">ZONE:</span>
                    <select
                      value={zoneFilter}
                      onChange={(e) => setZoneFilter(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/80"
                    >
                      <option value="ALL">All Zones</option>
                      <option value="Mattuthavani">Mattuthavani</option>
                      <option value="Periyar">Periyar</option>
                      <option value="Goripalayam">Goripalayam</option>
                      <option value="Arappalayam">Arappalayam</option>
                      <option value="Anna Nagar">Anna Nagar</option>
                    </select>
                  </div>

                  {/* Filter by Category */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">CAT:</span>
                    <select
                      value={categoryFilter}
                      onChange={(e) => setCategoryFilter(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/80"
                    >
                      <option value="ALL">All Categories</option>
                      <option value="Roads & Highways">Roads & Highways</option>
                      <option value="Sanitation & Waste">Sanitation & Waste</option>
                      <option value="Electrical & Streetlights">Electrical</option>
                      <option value="Water Supply">Water Supply</option>
                      <option value="Public Safety">Public Safety</option>
                    </select>
                  </div>

                  {/* Filter by Severity */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono text-slate-500 uppercase shrink-0">SEV:</span>
                    <select
                      value={severityFilter}
                      onChange={(e) => setSeverityFilter(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-850 rounded-lg px-2 py-2 text-xs text-slate-300 focus:outline-none focus:border-indigo-500/80"
                    >
                      <option value="ALL">All Severities</option>
                      <option value="1">1 (Low)</option>
                      <option value="2">2 (Minor)</option>
                      <option value="3">3 (Moderate)</option>
                      <option value="4">4 (High)</option>
                      <option value="5">5 (Critical)</option>
                    </select>
                  </div>

                </div>

              </div>

              {/* Table Data */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-950/60 border-b border-slate-900 text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                      <th className="py-3 px-4">Complaint ID</th>
                      <th className="py-3 px-4">Target Zone</th>
                      <th className="py-3 px-4">Extracted Category</th>
                      <th className="py-3 px-4 min-w-[180px] max-w-[280px]">Translated English Text</th>
                      <th className="py-3 px-4 text-center">Severity Index</th>
                      <th className="py-3 px-4">Target Ingestion Status</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900 text-xs">
                    {filteredGrievances.length > 0 ? (
                      filteredGrievances.map((g) => (
                        <tr
                          key={g.id}
                          onClick={() => setSelectedGrievance(g)}
                          className={`hover:bg-slate-900/60 transition-colors cursor-pointer ${
                            selectedGrievance?.id === g.id ? "bg-slate-900/80 border-l-2 border-teal-500" : ""
                          }`}
                        >
                          {/* Complaint ID */}
                          <td className="py-3.5 px-4 font-mono text-slate-300 font-medium">
                            <div className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-teal-500"></span>
                              <span>{g.id}</span>
                            </div>
                          </td>

                          {/* Zone */}
                          <td className="py-3.5 px-4 font-semibold text-white">
                            <span className="inline-flex items-center gap-1">
                              <MapPin className="w-3 h-3 text-indigo-400 shrink-0" />
                              {g.zone}
                            </span>
                          </td>

                          {/* Category */}
                          <td className="py-3.5 px-4">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium inline-block border ${
                              g.category === "Roads & Highways" 
                                ? "bg-amber-500/10 text-amber-400 border-amber-500/20"
                                : g.category === "Water Supply"
                                ? "bg-cyan-500/10 text-cyan-400 border-cyan-500/20"
                                : g.category === "Sanitation & Waste"
                                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                                : g.category === "Electrical & Streetlights"
                                ? "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"
                                : "bg-rose-500/10 text-rose-400 border-rose-500/20"
                            }`}>
                              {g.category}
                            </span>
                          </td>

                          {/* Translated English Text */}
                          <td className="py-3.5 px-4 text-slate-300 line-clamp-2 min-w-[180px] max-w-[280px]">
                            {g.translatedText}
                          </td>

                          {/* Severity level */}
                          <td className="py-3.5 px-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              {/* Small color representation blocks for severity */}
                              <div className="flex gap-0.5">
                                {Array.from({ length: 5 }).map((_, i) => (
                                  <div
                                    key={i}
                                    className={`w-1.5 h-3 rounded-sm ${
                                      i < g.severity
                                        ? g.severity >= 4
                                          ? "bg-rose-500"
                                          : g.severity === 3
                                          ? "bg-amber-400"
                                          : "bg-emerald-500"
                                        : "bg-slate-850"
                                    }`}
                                  ></div>
                                ))}
                              </div>
                              <span className={`font-mono font-bold text-xs ${
                                g.severity >= 4 
                                  ? "text-rose-500" 
                                  : g.severity === 3 
                                  ? "text-amber-400" 
                                  : "text-emerald-400"
                              }`}>
                                {g.severity}
                              </span>
                            </div>
                          </td>

                          {/* Target BigQuery Ingestion Status */}
                          <td className="py-3.5 px-4 font-mono text-[10px]">
                            <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
                              {/* Flashing green dot */}
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping shrink-0"></span>
                              <span className="font-semibold tracking-wide">SUCCESS_LOGGED</span>
                            </div>
                          </td>

                          {/* Action Delete */}
                          <td className="py-3.5 px-4 text-right">
                            <button
                              onClick={(e) => deleteGrievance(g.id, e)}
                              className="p-1 rounded text-slate-500 hover:text-rose-500 hover:bg-rose-500/10 transition-all cursor-pointer"
                              title="Remove record from simulated table buffer"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td colSpan={7} className="py-8 px-4 text-center text-slate-500">
                          <AlertTriangle className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                          <p className="text-sm font-medium">No ledger records found matching the active filters.</p>
                          <p className="text-xs text-slate-600 mt-1">Try resetting filter values or ingest a new regional payload sequence.</p>
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

            </div>

            {/* Deep Cognitive Diagnostic Inspector Drawer / Detail display */}
            {selectedGrievance && (
              <div className="bg-slate-900/50 border border-slate-900 rounded-xl p-5 md:p-6 space-y-4">
                
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-teal-400" />
                    <h4 className="font-display font-semibold text-white">Grievance Ingestion Diagnostic Report</h4>
                  </div>
                  <span className="text-xs font-mono px-2 py-1 bg-slate-950 text-indigo-400 border border-slate-800 rounded">
                    ID: {selectedGrievance.id}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">
                  
                  {/* Original Input vs Scrubbed Text */}
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                        <Smartphone className="w-3.5 h-3.5 text-indigo-400" />
                        <span>RAW INPUT STREAM TRANSCRIPT (Tamil/English mix)</span>
                      </span>
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 text-slate-300 leading-relaxed italic">
                        "{selectedGrievance.rawText}"
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                        <EyeOff className="w-3.5 h-3.5 text-teal-400" />
                        <span>PII GUARD REDACTION SCRUB LEVEL</span>
                      </span>
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 text-slate-300 leading-relaxed">
                        "{selectedGrievance.redactedText}"
                      </div>
                      {selectedGrievance.hasPii && (
                        <span className="text-[10px] text-amber-500 font-mono block">
                          ⚡ Phone number token detected and masked: "{selectedGrievance.redactedPhone}"
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Smart Categorization & Schema Generation Details */}
                  <div className="space-y-4">
                    <div className="space-y-1.5">
                      <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                        <Languages className="w-3.5 h-3.5 text-cyan-400" />
                        <span>SEMANTIC MAP TRANSLATOR</span>
                      </span>
                      <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 text-slate-300 leading-relaxed font-sans">
                        {selectedGrievance.translatedText}
                      </div>
                    </div>

                    <div className="bg-slate-950 p-4 rounded-lg border border-slate-900 space-y-2.5 font-mono text-xs">
                      <span className="text-[10px] text-slate-500 uppercase tracking-widest block font-bold">COGNITIVE SCHEMA MAP</span>
                      
                      <div className="grid grid-cols-2 gap-3 text-[11px] pt-1">
                        <div className="flex justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-slate-500">GIS ZONE:</span>
                          <span className="text-white font-semibold">{selectedGrievance.zone}</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-slate-500">CLASSIFIER CONFIDENCE:</span>
                          <span className="text-teal-400 font-bold">{Math.round(selectedGrievance.confidenceScore * 100)}%</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-slate-500">SEVERITY CODE:</span>
                          <span className={`font-bold ${selectedGrievance.severity >= 4 ? "text-rose-500" : "text-amber-400"}`}>{selectedGrievance.severity} / 5</span>
                        </div>
                        <div className="flex justify-between border-b border-slate-900 pb-1.5">
                          <span className="text-slate-500">LOG DATE:</span>
                          <span className="text-slate-300">{selectedGrievance.timestamp.split(" ")[0]}</span>
                        </div>
                      </div>

                      <div className="pt-2 text-[10px] text-slate-400 bg-slate-900/60 p-2 rounded border border-slate-900 flex justify-between items-center">
                        <span className="flex items-center gap-1">
                          <Database className="w-3 h-3 text-emerald-400 animate-pulse" />
                          <span>Pushed to table: <span className="text-slate-200">mdu_corp_ledger</span></span>
                        </span>
                        <span className="text-emerald-400 font-bold">COMMIT_SUCCESS</span>
                      </div>
                    </div>

                  </div>

                </div>

              </div>
            )}

          </div>

        </div>

      </main>

      {/* Modern, minimalist footer with no telemetry clutter */}
      <footer id="app-footer" className="mt-auto border-t border-slate-900 bg-slate-950 py-6 px-6">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 font-mono">
          <div>
            <span>V.O.I.C.E. AI Municipal Grievance Ingestion Node © 2026</span>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-slate-600">Madurai Corporation Smart City Initiative</span>
            <span className="text-slate-600">|</span>
            <span className="text-slate-600">Secure AES-256 PII Redaction Layer Enabled</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
